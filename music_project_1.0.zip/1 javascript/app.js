window.addEventListener("load", () => {
    let long;
    let lat;

    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(position => {
            long = position.coords.longitude;
            lat = position.coords.latitude;

            const proxy = "https://cors-anywhere.herokuapp.com/";
            const api = `${proxy}("https://weatherbit-v1-mashape.p.rapidapi.com/current?lang=en&lon=${long}&lat=${lat}", {
                "method": "GET",
                "headers": {
                    "x-rapidapi-host": "weatherbit-v1-mashape.p.rapidapi.com",
                    "x-rapidapi-key": "8a8eea1b2fmshcdaa7735dd2e95dp1587b1jsnaeefb6d5c9da"
                }
            })`;

            fetch(api)
            .then(response => {
                console.log(response);
            })
            .catch(err => {
                console.log(err);
            });
        });
    }
});